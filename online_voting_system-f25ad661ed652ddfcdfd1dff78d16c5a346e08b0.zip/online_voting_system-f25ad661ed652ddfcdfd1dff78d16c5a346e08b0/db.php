<?php

$con = mysqli_connect('localhost','root','','voting');

if($con)
{
   
}
else{
    die(mysqli_error($con));
}
?>